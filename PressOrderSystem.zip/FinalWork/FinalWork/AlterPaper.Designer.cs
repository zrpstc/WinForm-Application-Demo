﻿namespace FinalWork
{
    partial class AlterPaper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_clearOk = new System.Windows.Forms.Button();
            this.bt_alterPOk = new System.Windows.Forms.Button();
            this.tb_alterpublic = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_alterprice = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rtb_altercontent = new System.Windows.Forms.RichTextBox();
            this.tb_altername = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cb_alterdate = new System.Windows.Forms.ComboBox();
            this.cb_altercategory = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.bt_clearOk);
            this.panel1.Controls.Add(this.bt_alterPOk);
            this.panel1.Controls.Add(this.tb_alterpublic);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tb_alterprice);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.rtb_altercontent);
            this.panel1.Controls.Add(this.tb_altername);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.cb_alterdate);
            this.panel1.Controls.Add(this.cb_altercategory);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(759, 501);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(391, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 36;
            this.label3.Text = "出版周期";
            // 
            // bt_clearOk
            // 
            this.bt_clearOk.Location = new System.Drawing.Point(464, 419);
            this.bt_clearOk.Name = "bt_clearOk";
            this.bt_clearOk.Size = new System.Drawing.Size(100, 42);
            this.bt_clearOk.TabIndex = 43;
            this.bt_clearOk.Text = "重置";
            this.bt_clearOk.UseVisualStyleBackColor = true;
            this.bt_clearOk.Click += new System.EventHandler(this.bt_clearOk_Click);
            // 
            // bt_alterPOk
            // 
            this.bt_alterPOk.Location = new System.Drawing.Point(241, 419);
            this.bt_alterPOk.Name = "bt_alterPOk";
            this.bt_alterPOk.Size = new System.Drawing.Size(100, 42);
            this.bt_alterPOk.TabIndex = 42;
            this.bt_alterPOk.Text = "确认修改";
            this.bt_alterPOk.UseVisualStyleBackColor = true;
            this.bt_alterPOk.Click += new System.EventHandler(this.bt_alterPOk_Click);
            // 
            // tb_alterpublic
            // 
            this.tb_alterpublic.Location = new System.Drawing.Point(213, 109);
            this.tb_alterpublic.Name = "tb_alterpublic";
            this.tb_alterpublic.Size = new System.Drawing.Size(128, 28);
            this.tb_alterpublic.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(102, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 18);
            this.label2.TabIndex = 34;
            this.label2.Text = "出版社";
            // 
            // tb_alterprice
            // 
            this.tb_alterprice.Location = new System.Drawing.Point(213, 184);
            this.tb_alterprice.Name = "tb_alterprice";
            this.tb_alterprice.Size = new System.Drawing.Size(128, 28);
            this.tb_alterprice.TabIndex = 40;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(102, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 18);
            this.label5.TabIndex = 39;
            this.label5.Text = "每期报价";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(102, 262);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 41;
            this.label6.Text = "报刊摘要";
            // 
            // rtb_altercontent
            // 
            this.rtb_altercontent.Location = new System.Drawing.Point(213, 259);
            this.rtb_altercontent.Name = "rtb_altercontent";
            this.rtb_altercontent.Size = new System.Drawing.Size(423, 137);
            this.rtb_altercontent.TabIndex = 45;
            this.rtb_altercontent.Text = "";
            // 
            // tb_altername
            // 
            this.tb_altername.Location = new System.Drawing.Point(213, 39);
            this.tb_altername.Name = "tb_altername";
            this.tb_altername.Size = new System.Drawing.Size(128, 28);
            this.tb_altername.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 18);
            this.label1.TabIndex = 32;
            this.label1.Text = "报刊名";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(347, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 18);
            this.label7.TabIndex = 46;
            this.label7.Text = "元";
            // 
            // cb_alterdate
            // 
            this.cb_alterdate.FormattingEnabled = true;
            this.cb_alterdate.Items.AddRange(new object[] {
            "日报（1天）",
            "周报（7天）",
            "旬刊（10天）",
            "半月刊（15天）",
            "月刊（30天）",
            "双月刊（60天）",
            "季刊（3个月）",
            "半年刊（6个月）",
            "年刊（12个月）"});
            this.cb_alterdate.Location = new System.Drawing.Point(487, 109);
            this.cb_alterdate.Name = "cb_alterdate";
            this.cb_alterdate.Size = new System.Drawing.Size(172, 26);
            this.cb_alterdate.TabIndex = 44;
            // 
            // cb_altercategory
            // 
            this.cb_altercategory.FormattingEnabled = true;
            this.cb_altercategory.Location = new System.Drawing.Point(487, 39);
            this.cb_altercategory.Name = "cb_altercategory";
            this.cb_altercategory.Size = new System.Drawing.Size(172, 26);
            this.cb_altercategory.TabIndex = 38;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(391, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 37;
            this.label4.Text = "报刊类别";
            // 
            // AlterPaper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 501);
            this.Controls.Add(this.panel1);
            this.Name = "AlterPaper";
            this.Text = "修改报刊信息";
            this.Load += new System.EventHandler(this.AlterPaper_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox rtb_altercontent;
        private System.Windows.Forms.ComboBox cb_alterdate;
        private System.Windows.Forms.Button bt_clearOk;
        private System.Windows.Forms.Button bt_alterPOk;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_alterprice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_altercategory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_alterpublic;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_altername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
    }
}